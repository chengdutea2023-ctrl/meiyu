# 猜拳识别实验室：认识判别式 AI

这是接入“智美教育新生态业务底座”的静态内部课件。

## 课件目标

学生通过摄像头观察模型对石头、布、剪刀、无手势/未知输入的分类输出，理解判别式 AI 的边界：它主要判断输入属于哪个已知类别，并不等于什么都认识。

## 本地预览

```bash
cd coursewares/rps-discriminative-ai
python3 -m http.server 4178
```

访问：

```text
http://localhost:4178/static/index.html?demo=1
```

`demo=1` 只用于本地预览，不会提交到业务底座。

## 模型文件

正式交付前，把 Teachable Machine 导出的 TensorFlow.js 模型放入：

```text
static/models/rps/
```

需要包含：

```text
model.json
metadata.json
*.bin
```

当前源码已包含模型缺失时的课堂演示兜底；正式交付前应替换为真实模型。

## 平台接入

课件会从 URL 读取：

```text
launchToken
platformApiBase
returnUrl
```

启动时调用：

```text
POST /course-runtime/launch/verify
```

完成时调用：

```text
POST /course-runtime/launch/records
```

课件不上传摄像头图片，只上报结构化识别结果、分数、耗时和 summary。

## 打包

```bash
cd coursewares/rps-discriminative-ai
zip -r ../../rps-discriminative-ai-current.zip manifest.json static \
  -x "*/node_modules/*" "*/.git/*" "*/.DS_Store" "*/.env"
```

上传 ZIP 前请确认 `static/models/rps/` 已放入正式模型文件。
