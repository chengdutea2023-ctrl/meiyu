# 猜拳模型放置说明

把 Teachable Machine 导出的 TensorFlow.js 模型文件放在本目录。

需要的文件通常是：

```text
model.json
metadata.json
*.bin
```

推荐类别：

```text
rock
paper
scissors
none
```

如果使用 Teachable Machine 默认数字标签，也支持：

```text
0 = 石头
1 = 布
2 = 剪刀
None = 无手势/未知
```

不要把只指向 `teachablemachine.withgoogle.com/models/...` 的远程链接作为最终交付。最终上传业务底座的 ZIP 必须包含模型文件本体。
