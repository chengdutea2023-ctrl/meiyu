const MODEL_BASE = './models/rps/';
const CONFIDENCE_THRESHOLD = 0.8;
const UNKNOWN_MARGIN = 0.2;

const labelMap = new Map([
  ['0', 'rock'],
  ['rock', 'rock'],
  ['stone', 'rock'],
  ['石头', 'rock'],
  ['1', 'paper'],
  ['paper', 'paper'],
  ['布', 'paper'],
  ['2', 'scissors'],
  ['scissors', 'scissors'],
  ['scissor', 'scissors'],
  ['剪刀', 'scissors'],
  ['none', 'none'],
  ['no hand', 'none'],
  ['unknown', 'none'],
  ['无手势', 'none'],
  ['未知', 'none'],
]);

const displayLabels = {
  rock: '石头',
  paper: '布',
  scissors: '剪刀',
  none: '无手势/未知',
};

const app = {
  params: new URLSearchParams(window.location.search),
  launchToken: '',
  platformApiBase: '',
  returnUrl: '',
  demoMode: false,
  launch: null,
  model: null,
  webcam: null,
  animationId: null,
  modelReady: false,
  cameraReady: false,
  fallbackMode: false,
  startedAt: Date.now(),
  currentPrediction: null,
  lastPredictions: [],
  completedGestures: {
    rock: null,
    paper: null,
    scissors: null,
  },
  unknownResult: null,
  quizScore: 0,
  quizChecked: false,
  submitted: false,
};

const els = {};

document.addEventListener('DOMContentLoaded', () => {
  cacheElements();
  bindEvents();
  boot();
});

function cacheElements() {
  Object.assign(els, {
    launchPanel: document.querySelector('#launchPanel'),
    launchTitle: document.querySelector('#launchTitle'),
    launchMessage: document.querySelector('#launchMessage'),
    startButton: document.querySelector('#startButton'),
    workspace: document.querySelector('#workspace'),
    webcamMount: document.querySelector('#webcamMount'),
    modeBadge: document.querySelector('#modeBadge'),
    runtimeStatus: document.querySelector('#runtimeStatus'),
    cameraButton: document.querySelector('#cameraButton'),
    retryModelButton: document.querySelector('#retryModelButton'),
    predictionLabel: document.querySelector('#predictionLabel'),
    confidenceValue: document.querySelector('#confidenceValue'),
    confidenceBars: document.querySelector('#confidenceBars'),
    teachingNote: document.querySelector('#teachingNote'),
    fallbackPanel: document.querySelector('#fallbackPanel'),
    recordUnknownButton: document.querySelector('#recordUnknownButton'),
    unknownResultTitle: document.querySelector('#unknownResultTitle'),
    unknownResultText: document.querySelector('#unknownResultText'),
    quizForm: document.querySelector('#quizForm'),
    scoreQuizButton: document.querySelector('#scoreQuizButton'),
    finalScore: document.querySelector('#finalScore'),
    summaryPreview: document.querySelector('#summaryPreview'),
    submitButton: document.querySelector('#submitButton'),
    submitStatus: document.querySelector('#submitStatus'),
  });
}

function bindEvents() {
  document.querySelectorAll('[data-back]').forEach((button) => {
    button.addEventListener('click', backToStudentPortal);
  });

  els.startButton.addEventListener('click', startLesson);
  els.cameraButton.addEventListener('click', startCamera);
  els.retryModelButton.addEventListener('click', loadModel);
  els.recordUnknownButton.addEventListener('click', recordUnknown);
  els.scoreQuizButton.addEventListener('click', scoreQuiz);
  els.submitButton.addEventListener('click', submitRecord);

  document.querySelectorAll('[data-record]').forEach((button) => {
    button.addEventListener('click', () => recordGesture(button.dataset.record));
  });

  document.querySelectorAll('[data-simulate]').forEach((button) => {
    button.addEventListener('click', () => simulatePrediction(button.dataset.simulate));
  });

  document.querySelectorAll('[data-step-tab]').forEach((button) => {
    button.addEventListener('click', () => showStep(button.dataset.stepTab));
  });
}

async function boot() {
  app.launchToken = app.params.get('launchToken') || '';
  app.platformApiBase = app.params.get('platformApiBase') || '';
  app.returnUrl = app.params.get('returnUrl') || '';
  app.demoMode = app.params.get('demo') === '1';

  if (!app.launchToken || !app.platformApiBase) {
    if (app.demoMode) {
      app.launch = {
        student: { name: '本地演示学生' },
        courseware: { title: '猜拳识别实验室' },
      };
      setLaunchReady('本地演示模式', '未连接业务底座；可以完整预览流程，但提交不会写入后台。');
      return;
    }

    els.launchTitle.textContent = '请从学生后台进入课件';
    els.launchMessage.textContent = '当前链接缺少 launchToken 或 platformApiBase，无法确认学生身份和任务。';
    els.startButton.disabled = true;
    return;
  }

  try {
    els.launchTitle.textContent = '正在校验学生身份';
    app.launch = await platformPost('/course-runtime/launch/verify', {
      launchToken: app.launchToken,
    });
    setLaunchReady('校验通过', '可以开始识别实验。');
  } catch (error) {
    els.launchTitle.textContent = '启动校验失败';
    els.launchMessage.textContent = getErrorMessage(error);
    els.startButton.disabled = true;
  }
}

function setLaunchReady(title, message) {
  els.launchTitle.textContent = title;
  els.launchMessage.textContent = message;
  els.startButton.disabled = false;
}

async function startLesson() {
  els.launchPanel.classList.add('is-hidden');
  els.workspace.classList.remove('is-hidden');
  setRuntimeStatus('正在加载本地模型。');
  await loadModel();
  updateSummaryPreview();
}

async function loadModel() {
  stopPredictionLoop();
  app.modelReady = false;
  app.model = null;

  try {
    if (!window.tmImage) {
      throw new Error('Teachable Machine 运行库未加载。');
    }

    app.model = await window.tmImage.load(`${MODEL_BASE}model.json`, `${MODEL_BASE}metadata.json`);
    app.modelReady = true;
    app.fallbackMode = false;
    els.fallbackPanel.classList.add('is-hidden');
    els.modeBadge.textContent = '真实模型';
    setRuntimeStatus('本地模型已加载。开启摄像头后可开始识别。');
    renderPredictionBars([]);
  } catch (error) {
    app.fallbackMode = true;
    els.modeBadge.textContent = '演示模式';
    els.fallbackPanel.classList.remove('is-hidden');
    setRuntimeStatus(
      `没有加载到正式模型：${getErrorMessage(error)}。已切换到课堂演示按钮。`,
      true,
    );
    renderPredictionBars([
      { className: 'rock', probability: 0 },
      { className: 'paper', probability: 0 },
      { className: 'scissors', probability: 0 },
      { className: 'none', probability: 0 },
    ]);
  }
}

async function startCamera() {
  if (!window.tmImage) {
    setRuntimeStatus('缺少 Teachable Machine 运行库，无法开启摄像头。', true);
    return;
  }

  try {
    if (app.webcam) {
      stopPredictionLoop();
      await app.webcam.stop();
      app.webcam = null;
      app.cameraReady = false;
    }

    const flip = true;
    app.webcam = new window.tmImage.Webcam(320, 320, flip);
    await app.webcam.setup();
    await app.webcam.play();
    app.cameraReady = true;

    els.webcamMount.innerHTML = '';
    els.webcamMount.appendChild(app.webcam.canvas);
    els.cameraButton.textContent = '重新开启摄像头';

    if (app.modelReady) {
      setRuntimeStatus('摄像头已开启，正在实时识别。');
      predictLoop();
    } else {
      setRuntimeStatus('摄像头已开启，但本地模型还没有加载。可以先使用课堂演示按钮。', true);
    }
  } catch (error) {
    app.cameraReady = false;
    app.fallbackMode = true;
    els.fallbackPanel.classList.remove('is-hidden');
    setRuntimeStatus(`摄像头不可用：${getErrorMessage(error)}。已提供课堂演示按钮。`, true);
  }
}

async function predictLoop() {
  if (!app.webcam || !app.model || !app.modelReady) {
    return;
  }

  app.webcam.update();
  const predictions = await app.model.predict(app.webcam.canvas);
  handlePredictions(predictions, 'camera');
  app.animationId = window.requestAnimationFrame(predictLoop);
}

function stopPredictionLoop() {
  if (app.animationId) {
    window.cancelAnimationFrame(app.animationId);
    app.animationId = null;
  }
}

function handlePredictions(rawPredictions, source) {
  const predictions = rawPredictions
    .map((item) => ({
      className: normalizeLabel(item.className),
      originalClassName: String(item.className),
      probability: Number(item.probability || 0),
    }))
    .sort((a, b) => b.probability - a.probability);

  const top = predictions[0] || { className: 'none', originalClassName: 'none', probability: 0 };
  const second = predictions[1] || { probability: 0 };
  const stable = top.probability >= CONFIDENCE_THRESHOLD && top.probability - second.probability >= UNKNOWN_MARGIN;
  const current = {
    label: top.className,
    displayLabel: displayLabels[top.className] || top.originalClassName,
    confidence: top.probability,
    stable,
    source,
    at: new Date().toISOString(),
  };

  app.currentPrediction = current;
  app.lastPredictions.unshift(current);
  app.lastPredictions = app.lastPredictions.slice(0, 20);

  updatePredictionUi(current, predictions);
}

function normalizeLabel(label) {
  const key = String(label).trim().toLowerCase();
  return labelMap.get(key) || key;
}

function updatePredictionUi(current, predictions) {
  const confidencePercent = Math.round(current.confidence * 100);
  els.predictionLabel.textContent = current.stable
    ? current.displayLabel
    : '无法可靠判断';
  els.confidenceValue.textContent = `${confidencePercent}%`;
  els.teachingNote.textContent = current.stable
    ? `模型认为当前输入最像“${current.displayLabel}”。这是判别式 AI 的分类结果。`
    : '置信度不足或类别差距太小，不能把这次输出当成可靠答案。';
  renderPredictionBars(predictions);
}

function renderPredictionBars(predictions) {
  const rows = predictions.length ? predictions : [];
  els.confidenceBars.innerHTML = rows
    .map((item) => {
      const label = displayLabels[item.className] || item.originalClassName || item.className;
      const percent = Math.round((item.probability || 0) * 100);
      return `
        <div class="bar-row">
          <strong>${escapeHtml(label)}</strong>
          <span class="bar-track"><span class="bar-fill" style="width: ${percent}%"></span></span>
          <span>${percent}%</span>
        </div>
      `;
    })
    .join('');
}

function simulatePrediction(label) {
  const values = ['rock', 'paper', 'scissors', 'none'];
  const predictions = values.map((value) => ({
    className: value,
    originalClassName: value,
    probability: value === label ? 0.92 : 0.02,
  }));
  handlePredictions(predictions, 'simulation');
  setRuntimeStatus('已生成一次课堂演示识别结果。');
}

function recordGesture(gesture) {
  const current = app.currentPrediction;
  if (!current) {
    setRuntimeStatus('请先让模型完成一次识别。', true);
    return;
  }

  const passed = current.label === gesture && current.stable;
  app.completedGestures[gesture] = {
    expected: gesture,
    predicted: current.label,
    confidence: current.confidence,
    passed,
    source: current.source,
    at: current.at,
  };

  const card = document.querySelector(`[data-gesture-card="${gesture}"]`);
  if (card) {
    card.classList.toggle('is-complete', passed);
  }

  setRuntimeStatus(
    passed
      ? `已记录“${displayLabels[gesture]}”稳定识别。`
      : `这次还没有稳定识别为“${displayLabels[gesture]}”，可以再试一次。`,
    !passed,
  );
  updateSummaryPreview();
}

function recordUnknown() {
  const current = app.currentPrediction;
  if (!current) {
    setRuntimeStatus('请先做一个第四手势，或点击演示按钮生成识别结果。', true);
    return;
  }

  const uncertain = !current.stable || current.label === 'none';
  app.unknownResult = {
    predicted: current.label,
    confidence: current.confidence,
    passed: uncertain,
    source: current.source,
    at: current.at,
  };

  els.unknownResultTitle.textContent = uncertain ? '未知挑战完成' : '模型仍然给出了稳定类别';
  els.unknownResultText.textContent = uncertain
    ? '这说明判别式 AI 有边界：它不一定认识训练类别之外的输入。'
    : `模型把它稳定判成“${displayLabels[current.label]}”。可以换一个更明显的第四手势再试。`;

  setRuntimeStatus(uncertain ? '已记录未知手势边界。' : '这次未知挑战还不够明显。', !uncertain);
  updateSummaryPreview();
}

function scoreQuiz() {
  const data = new FormData(els.quizForm);
  let score = 0;

  if (data.get('q1') === 'classify') score += 1;
  if (data.get('q2') === 'boundary') score += 1;

  const q3 = data.getAll('q3').sort().join(',');
  if (q3 === 'gesture,spam') score += 1;

  app.quizScore = score;
  app.quizChecked = true;
  setRuntimeStatus(`概念题完成：答对 ${score}/3。`);
  updateSummaryPreview();
}

function calculateScore() {
  const knownCount = Object.values(app.completedGestures).filter((item) => item?.passed).length;
  const knownScore = knownCount * 15;
  const unknownScore = app.unknownResult?.passed ? 25 : 0;
  const quizScore = app.quizScore * 10;
  return Math.min(100, knownScore + unknownScore + quizScore);
}

function getDurationSeconds() {
  return Math.max(1, Math.round((Date.now() - app.startedAt) / 1000));
}

function buildSummary() {
  const known = Object.entries(app.completedGestures).map(([gesture, result]) => ({
    gesture,
    title: displayLabels[gesture],
    predicted: result?.predicted || null,
    confidence: result ? roundConfidence(result.confidence) : null,
    passed: Boolean(result?.passed),
    source: result?.source || null,
  }));
  const knownCount = known.filter((item) => item.passed).length;
  const score = calculateScore();

  return {
    displayTitle: '猜拳识别实验室',
    brief: '完成石头剪刀布识别实验，并观察未知手势的模型边界',
    scoreText: `${score} 分`,
    resultItems: [
      { label: '已知手势', value: `${knownCount}/3` },
      { label: '未知挑战', value: app.unknownResult?.passed ? '已观察到边界' : '未完成' },
      { label: '概念题', value: app.quizChecked ? `${app.quizScore}/3` : '未检查' },
      { label: '耗时', value: `${getDurationSeconds()} 秒` },
    ],
    processSummary:
      '学生通过摄像头或课堂演示观察模型对石头、布、剪刀、无手势的分类输出，理解判别式 AI 根据已有类别做判断，遇到未知输入时可能无法可靠判别。',
    conceptTakeaway: '判别式 AI 的核心是判断输入属于哪个已知类别，而不是凭空生成新内容。',
    predictions: {
      known,
      unknown: app.unknownResult
        ? {
            predicted: app.unknownResult.predicted,
            confidence: roundConfidence(app.unknownResult.confidence),
            passed: app.unknownResult.passed,
            source: app.unknownResult.source,
          }
        : null,
      recent: app.lastPredictions.slice(0, 8).map((item) => ({
        label: item.label,
        confidence: roundConfidence(item.confidence),
        stable: item.stable,
        source: item.source,
      })),
    },
  };
}

function updateSummaryPreview() {
  const summary = buildSummary();
  const score = calculateScore();
  els.finalScore.textContent = String(score);
  els.summaryPreview.innerHTML = `
    <strong>${escapeHtml(summary.displayTitle)}</strong>
    <span>${escapeHtml(summary.brief)}</span>
    ${summary.resultItems
      .map((item) => `<span>${escapeHtml(item.label)}：${escapeHtml(item.value)}</span>`)
      .join('')}
  `;
}

async function submitRecord() {
  updateSummaryPreview();
  const score = calculateScore();
  const durationSeconds = getDurationSeconds();
  const summary = buildSummary();

  if (app.demoMode) {
    app.submitted = true;
    els.submitStatus.textContent = '本地演示模式：已生成提交数据，但未写入业务底座。';
    els.submitStatus.classList.remove('is-error');
    return;
  }

  try {
    els.submitStatus.textContent = '正在提交到业务底座。';
    els.submitStatus.classList.remove('is-error');
    await platformPost('/course-runtime/launch/records', {
      launchToken: app.launchToken,
      status: 'COMPLETED',
      score,
      durationSeconds,
      summary,
    });
    app.submitted = true;
    els.submitStatus.textContent = '已提交，老师可以在后台查看结果。';
  } catch (error) {
    els.submitStatus.textContent = `提交失败：${getErrorMessage(error)}`;
    els.submitStatus.classList.add('is-error');
  }
}

function showStep(step) {
  document.querySelectorAll('[data-step-panel]').forEach((panel) => {
    panel.classList.toggle('is-hidden', panel.dataset.stepPanel !== step);
  });
  document.querySelectorAll('[data-step-tab]').forEach((tab) => {
    tab.classList.toggle('is-active', tab.dataset.stepTab === step);
  });
  updateSummaryPreview();
}

function requireLaunchContext() {
  if (!app.launchToken || !app.platformApiBase) {
    throw new Error('请从学生后台进入课件');
  }
}

async function platformPost(path, body) {
  requireLaunchContext();
  const response = await fetch(`${app.platformApiBase}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.message || '底座接口请求失败');
  }
  return data;
}

function backToStudentPortal() {
  if (app.returnUrl) {
    window.location.href = app.returnUrl;
    return;
  }
  window.history.back();
}

function setRuntimeStatus(message, isError = false) {
  els.runtimeStatus.textContent = message;
  els.runtimeStatus.classList.toggle('is-error', isError);
}

function roundConfidence(value) {
  return Math.round(Number(value || 0) * 1000) / 1000;
}

function getErrorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
